import express from "express";
import dotenv from "dotenv";
dotenv.config();
const app=express(),PORT=process.env.PORT||3000,KEY=process.env.API_FOOTBALL_KEY,BASE="https://v3.football.api-sports.io";
app.use(express.json());app.use(express.static("public"));
async function api(path){const r=await fetch(BASE+path,{headers:{"x-apisports-key":KEY}});const d=await r.json();if(!r.ok||Object.keys(d.errors||{}).length)throw new Error(JSON.stringify(d.errors||r.status));return d}
function guard(req,res,next){if(!KEY)return res.status(500).json({error:"Missing API_FOOTBALL_KEY in .env"});next()}
app.get("/api/fixtures",guard,async(req,res)=>{try{res.json((await api(`/fixtures?date=${encodeURIComponent(req.query.date)}&timezone=Africa/Accra`)).response||[])}catch(e){res.status(502).json({error:e.message})}})
app.get("/api/match/:id",guard,async(req,res)=>{try{let id=+req.params.id,f=(await api(`/fixtures?id=${id}`)).response?.[0];if(!f)return res.status(404).json({error:"Fixture not found"});let h=f.teams.home.id,a=f.teams.away.id,l=f.league.id,s=f.league.season;let qs=[`/teams/statistics?league=${l}&season=${s}&team=${h}`,`/teams/statistics?league=${l}&season=${s}&team=${a}`,`/fixtures?team=${h}&last=10`,`/fixtures?team=${a}&last=10`,`/fixtures/headtohead?h2h=${h}-${a}&last=10`,`/injuries?league=${l}&season=${s}&team=${h}`,`/injuries?league=${l}&season=${s}&team=${a}`];let rs=await Promise.allSettled(qs.map(api)),v=i=>rs[i].status==="fulfilled"?rs[i].value?.response||[]:[];res.json({fixture:f,homeStats:v(0),awayStats:v(1),homeLast:v(2),awayLast:v(3),h2h:v(4),homeInjuries:v(5),awayInjuries:v(6)})}catch(e){res.status(502).json({error:e.message})}})
app.listen(PORT,()=>console.log(`V6 running at http://localhost:${PORT}`))